"""Direct reader for this PiperX recorder's one-episode LeRobot v3 datasets.

Reads original Parquet + MP4. No v2 export, video re-encoding, filtering,
segmentation, or validation split. Invalid flags are reported and retained.
"""
from collections import OrderedDict
from pathlib import Path
import bisect
import hashlib
import json
import math

import av
import numpy as np
import pyarrow.parquet as pq

from runtime import digest, read_json

CAMERAS = ("cam_high", "cam_left_wrist", "cam_right_wrist")
JOINTS = [f"{side}/{joint}" for side in ("left", "right") for joint in (*[f"joint{i}" for i in range(1, 7)], "gripper")]
JOINT_MASK = np.array([True] * 6 + [False] + [True] * 6 + [False])


def require(value, message):
    if not value:
        raise ValueError(message)


def inside(root, relative):
    p = (root / relative).resolve()
    require(p.is_relative_to(root.resolve()), f"Path escapes dataset: {relative}")
    return p


def scan(c, full_video=False):
    root = Path(c["source_root"])
    paths = sorted(p for p in root.glob("episode_*") if p.is_dir())
    require(bool(paths), f"No episode_* directories in {root}")
    records, excluded = [], []
    for p in paths:
        if p.name.endswith(".partial"):
            excluded.append({"episode": p.name, "reason": "unfinished .partial directory"})
            continue
        capture = read_json(p / "capture.json")
        if capture.get("complete") is not True:
            excluded.append({"episode": p.name, "reason": "capture.complete is not true"})
            continue
        require(not capture.get("writer_error"), f"{p}: writer_error")
        require(capture.get("joint_order") == JOINTS, f"{p}: joint order mismatch")
        require(capture.get("units", "").startswith("joint=rad, gripper opening=m"), f"{p}: unit mismatch")
        info = read_json(p / "meta/info.json")
        require(info["codebase_version"] == "v3.0" and info["total_episodes"] == 1, f"{p}: requires recorder single-episode v3.0 dataset")
        require(info["fps"] == c["fps"], f"{p}: FPS mismatch")
        meta_files = sorted((p / "meta/episodes").rglob("*.parquet"))
        rows = [row for f in meta_files for row in pq.read_table(f).to_pylist()]
        require(len(rows) == 1, f"{p}: expected one episode metadata row")
        meta = rows[0]
        data_file = inside(p, info["data_path"].format(chunk_index=meta["data/chunk_index"], file_index=meta["data/file_index"]))
        table = pq.read_table(data_file)
        n = table.num_rows
        require(n > 0 and n == meta["length"] == info["total_frames"] == capture["samples"], f"{p}: frame count mismatch")
        require(meta["dataset_from_index"] == 0 and meta["dataset_to_index"] == n, f"{p}: unsupported shared-dataset offsets")
        a = {k: np.asarray(table[k].to_pylist()) for k in ["observation.state", "action", "frame_index", "timestamp", "episode_index", "task_index", "observation.valid", "observation.host_timestamp_ns", "observations.arm_status", "observations.arm_error"]}
        for key in ["observation.state", "action"]:
            require(a[key].shape == (n, 14) and np.isfinite(a[key]).all(), f"{p}: invalid {key}; no silent frame dropping")
            names = info["features"][key]["names"]
            require([x.replace(".", "/") for x in names] == JOINTS, f"{p}: {key} feature order mismatch")
        require(np.array_equal(a["frame_index"], np.arange(n)), f"{p}: non-contiguous frame index")
        require(np.all(a["episode_index"] == meta["episode_index"]), f"{p}: episode indices mismatch")
        require(np.allclose(a["timestamp"], np.arange(n) / c["fps"], atol=1e-4, rtol=0), f"{p}: timestamp mismatch")
        tasks_file = p / "meta/tasks.parquet"
        task_rows = pq.read_table(tasks_file).to_pylist()
        tasks = {int(t["task_index"]): t.get("task", t.get("__index_level_0__")) for t in task_rows}
        require(all(tasks.get(int(i)) == capture["task"] for i in a["task_index"]), f"{p}: task metadata mismatch")
        task = c["task_override"].strip() or capture["task"]
        require(isinstance(task, str) and bool(task.strip()), f"{p}: empty task")
        videos = {}
        for camera in CAMERAS:
            key = f"observation.images.{camera}"
            prefix = f"videos/{key}"
            f = inside(p, info["video_path"].format(video_key=key, chunk_index=meta[prefix + "/chunk_index"], file_index=meta[prefix + "/file_index"]))
            offset = float(meta[prefix + "/from_timestamp"])
            require(offset == 0, f"{p}: requires standalone recorder video starting at zero")
            require(abs(float(meta[prefix + "/to_timestamp"]) - n / c["fps"]) < 1 / c["fps"], f"{p}: video duration metadata mismatch")
            shape = info["features"][key]["shape"]
            with av.open(str(f)) as container:
                stream = container.streams.video[0]
                stream.codec_context.thread_count = 1
                require([stream.height, stream.width, 3] == shape, f"{f}: video shape mismatch")
                # Fragmented MP4 may report zero (unknown) in its header. The check
                # command decodes all frames and verifies the authoritative count.
                require(stream.frames in (0, n), f"{f}: video frame count mismatch")
                require(abs(float(stream.average_rate) - c["fps"]) < 1e-6, f"{f}: video FPS mismatch")
                if full_video:
                    count = 0
                    for frame in container.decode(stream):
                        require(frame.time is not None and abs(frame.time - count / c["fps"]) < 0.5 / c["fps"], f"{f}: frame timestamp mismatch at {count}")
                        count += 1
                    require(count == n, f"{f}: decoded frame count mismatch")
            videos[camera] = str(f.relative_to(root))
        files = [p / "capture.json", p / "meta/info.json", tasks_file, data_file, *meta_files, *[root / f for f in videos.values()]]
        fingerprints = {str(f.relative_to(root)): digest(f) for f in files}
        host = a["observation.host_timestamp_ns"]
        records.append({"episode": p.name, "frames": n, "task": task, "data": str(data_file.relative_to(root)), "videos": videos, "hashes": fingerprints,
                        "invalid_frames_retained": int((~a["observation.valid"].astype(bool)).sum()),
                        "arm_flag_frames_retained": int(((a["observations.arm_status"] != 0).any(axis=1) | (a["observations.arm_error"] != 0).any(axis=1)).sum()),
                        "host_time_gaps_retained": int(((np.diff(host) <= 0) | (np.diff(host) > 1.5e9 / c["fps"])).sum()),
                        "success_flag": capture.get("success")})
        print(f"SCAN {p.name}: {n} frames retained", flush=True)
    require(bool(records), "No completed episodes")
    identity = {"episodes": records, "excluded": excluded, "fps": c["fps"], "action_horizon": c["action_horizon"], "task_override": c["task_override"]}
    fingerprint = hashlib.sha256(json.dumps(identity, sort_keys=True, ensure_ascii=False).encode()).hexdigest()
    return {**identity, "fingerprint": fingerprint, "source_root": str(root), "full_video_verified": full_video,
            "summary": {"episodes": len(records), "frames": sum(x["frames"] for x in records), "invalid_frames_retained": sum(x["invalid_frames_retained"] for x in records), "validation_frames": 0}}


def action_window(actions, frame, horizon):
    # Repeat the final action only at an episode boundary, never cross to another episode.
    return actions[np.minimum(np.arange(frame, frame + horizon), len(actions) - 1)].copy()


class NativeDataset:
    def __init__(self, manifest, horizon, transform=None):
        self.manifest, self.horizon, self.transform = manifest, horizon, transform
        self.root = Path(manifest["source_root"])
        self.ends = np.cumsum([e["frames"] for e in manifest["episodes"]]).tolist()
        self.signals = []
        for e in manifest["episodes"]:
            t = pq.read_table(self.root / e["data"], columns=["observation.state", "action"])
            self.signals.append(tuple(np.asarray(t[k].to_pylist(), dtype=np.float32) for k in ["observation.state", "action"]))
        self._containers = OrderedDict()

    def __len__(self):
        return self.ends[-1]

    def locate(self, index):
        if not 0 <= index < len(self):
            raise IndexError(index)
        ep = bisect.bisect_right(self.ends, index)
        return ep, index - (self.ends[ep - 1] if ep else 0)

    def image(self, file, frame_index):
        from openpi_client.image_tools import resize_with_pad
        key = str(file)
        if key in self._containers:
            container = self._containers.pop(key)
        else:
            container = av.open(key)
            container.streams.video[0].codec_context.thread_count = 1
        self._containers[key] = container
        while len(self._containers) > 6:
            self._containers.popitem(last=False)[1].close()
        stream = container.streams.video[0]
        target = frame_index / self.manifest["fps"]
        container.seek(math.floor(target / float(stream.time_base)), stream=stream, backward=True, any_frame=False)
        for f in container.decode(stream):
            if f.time is None:
                raise ValueError(f"Missing video timestamp: {file}")
            if f.time < target - 0.5 / self.manifest["fps"]:
                continue
            require(abs(f.time - target) < 0.5 / self.manifest["fps"], f"Video seek mismatch: {file} frame {frame_index}")
            return resize_with_pad(f.to_ndarray(format="rgb24"), 224, 224).transpose(2, 0, 1)
        raise ValueError(f"Video frame missing: {file} frame {frame_index}")

    def __getitem__(self, index):
        ep, frame = self.locate(int(index))
        state, actions = self.signals[ep]
        e = self.manifest["episodes"][ep]
        obs = {"state": state[frame].copy(), "actions": action_window(actions, frame, self.horizon), "prompt": e["task"],
               "images": {cam: self.image(self.root / e["videos"][cam], frame) for cam in CAMERAS}}
        return self.transform(obs) if self.transform is not None else obs

    def close(self):
        for container in self._containers.values():
            container.close()
        self._containers.clear()

    def __getstate__(self):
        return {**self.__dict__, "_containers": OrderedDict()}


class EpochBatches:
    """Deterministic complete epochs; resume without decoding skipped samples."""
    def __init__(self, size, batch_size, seed, start_step, stop_step):
        self.size, self.batch_size, self.seed = size, batch_size, seed
        self.start_step, self.stop_step = start_step, stop_step

    def __iter__(self):
        per_epoch = math.ceil(self.size / self.batch_size)
        cached_epoch, order = None, None
        for step in range(self.start_step, self.stop_step):
            epoch, batch = divmod(step, per_epoch)
            if cached_epoch != epoch:
                order = np.random.default_rng(np.random.SeedSequence([self.seed, epoch])).permutation(self.size)
                cached_epoch = epoch
            yield order[batch * self.batch_size:(batch + 1) * self.batch_size].tolist()

    def __len__(self):
        return self.stop_step - self.start_step


def collate(items, multiple):
    # Padding for device/accumulation divisibility is excluded from the loss.
    import jax
    real = len(items)
    padded = math.ceil(real / multiple) * multiple
    items = items + [items[-1]] * (padded - real)
    batch = jax.tree.map(lambda *xs: np.stack(xs), *items)
    batch["sample_mask"] = (np.arange(padded) < real).astype(np.float32)
    return batch
