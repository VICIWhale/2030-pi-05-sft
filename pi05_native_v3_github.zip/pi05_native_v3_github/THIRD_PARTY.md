# Third-party source provenance

OpenPI: https://github.com/Physical-Intelligence/openpi
Upstream commit: `215abfb217dbac7d5f1273282331b9b1866c0479`.
Bundled under `runtime/openpi`, with upstream LICENSE and LICENSE_GEMMA.txt.
Files changed relative to that commit: pyproject.toml, scripts/train.py, src/openpi/training/checkpoints.py, src/openpi/training/config.py, src/openpi/training/data_loader.py, uv.lock.
Changes include custom training configurations, gradient accumulation, checkpoint resume compatibility and dependency paths. These were inherited from the working training installation; bundled hashes pin their exact contents.

LeRobot: https://github.com/huggingface/lerobot
Bundled source version reports 0.1.0; exact upstream commit was not recorded in the source copy. Includes its Apache-2.0 LICENSE. Content is pinned by PACKAGE_MANIFEST.json. This package satisfies OpenPI imports; the native v3 reader is dataset.py.

No model weights are bundled. Their license/terms apply separately. The license for new project code has not been selected by the repository owner; third-party notices remain in force.
