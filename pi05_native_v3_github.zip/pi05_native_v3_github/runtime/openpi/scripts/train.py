import dataclasses
import functools
import json
import logging
import math
import platform
import pathlib
import time
from typing import Any

import etils.epath as epath
import flax.nnx as nnx
from flax.training import common_utils
import flax.traverse_util as traverse_util
import jax
import jax.experimental
import jax.numpy as jnp
from lerobot.common.datasets.lerobot_dataset import LeRobotDatasetMetadata
import numpy as np
import optax
import tqdm_loggable.auto as tqdm
import wandb

import openpi.models.model as _model
import openpi.shared.array_typing as at
import openpi.shared.nnx_utils as nnx_utils
import openpi.training.checkpoints as _checkpoints
import openpi.training.config as _config
import openpi.training.data_loader as _data_loader
import openpi.training.optimizer as _optimizer
import openpi.training.sharding as sharding
import openpi.training.utils as training_utils
import openpi.training.weight_loaders as _weight_loaders


def init_logging():
    """Custom logging format for better readability."""
    level_mapping = {"DEBUG": "D", "INFO": "I", "WARNING": "W", "ERROR": "E", "CRITICAL": "C"}

    class CustomFormatter(logging.Formatter):
        def format(self, record):
            record.levelname = level_mapping.get(record.levelname, record.levelname)
            return super().format(record)

    formatter = CustomFormatter(
        fmt="%(asctime)s.%(msecs)03d [%(levelname)s] %(message)-80s (%(process)d:%(filename)s:%(lineno)s)",
        datefmt="%H:%M:%S",
    )

    logger = logging.getLogger()
    logger.setLevel(logging.INFO)
    logger.handlers[0].setFormatter(formatter)


def init_wandb(config: _config.TrainConfig, *, resuming: bool, log_code: bool = False, enabled: bool = True):
    if not enabled:
        wandb.init(mode="disabled")
        return

    ckpt_dir = config.checkpoint_dir
    if not ckpt_dir.exists():
        raise FileNotFoundError(f"Checkpoint directory {ckpt_dir} does not exist.")
    if resuming:
        run_id = (ckpt_dir / "wandb_id.txt").read_text().strip()
        wandb.init(id=run_id, resume="must", project=config.project_name)
    else:
        wandb.init(
            name=config.exp_name,
            config=dataclasses.asdict(config),
            project=config.project_name,
        )
        (ckpt_dir / "wandb_id.txt").write_text(wandb.run.id)

    if log_code:
        wandb.run.log_code(epath.Path(__file__).parent.parent)


def _load_weights_and_validate(loader: _weight_loaders.WeightLoader, params_shape: at.Params) -> at.Params:
    """Loads and validates the weights. Returns a loaded subset of the weights."""
    loaded_params = loader.load(params_shape)
    at.check_pytree_equality(expected=params_shape, got=loaded_params, check_shapes=True, check_dtypes=True)

    # Remove jax.ShapeDtypeStruct from the loaded params. This makes sure that only the loaded params are returned.
    return traverse_util.unflatten_dict(
        {k: v for k, v in traverse_util.flatten_dict(loaded_params).items() if not isinstance(v, jax.ShapeDtypeStruct)}
    )


@at.typecheck
def init_train_state(
    config: _config.TrainConfig, init_rng: at.KeyArrayLike, mesh: jax.sharding.Mesh, *, resume: bool
) -> tuple[training_utils.TrainState, Any]:
    tx = _optimizer.create_optimizer(config.optimizer, config.lr_schedule, weight_decay_mask=None)

    def init(rng: at.KeyArrayLike, partial_params: at.Params | None = None) -> training_utils.TrainState:
        rng, model_rng = jax.random.split(rng)
        # initialize the model (and its parameters).
        model = config.model.create(model_rng)

        # Merge the partial params into the model.
        if partial_params is not None:
            graphdef, state = nnx.split(model)
            # This will produce an error if the partial params are not a subset of the state.
            state.replace_by_pure_dict(partial_params)
            model = nnx.merge(graphdef, state)

        params = nnx.state(model)
        # Convert frozen params to bfloat16.
        params = nnx_utils.state_map(params, config.freeze_filter, lambda p: p.replace(p.value.astype(jnp.bfloat16)))

        return training_utils.TrainState(
            step=0,
            params=params,
            model_def=nnx.graphdef(model),
            tx=tx,
            opt_state=tx.init(params.filter(config.trainable_filter)),
            ema_decay=config.ema_decay,
            ema_params=None if config.ema_decay is None else params,
        )

    train_state_shape = jax.eval_shape(init, init_rng)
    state_sharding = sharding.fsdp_sharding(train_state_shape, mesh, log=True)

    if resume:
        return train_state_shape, state_sharding

    partial_params = _load_weights_and_validate(config.weight_loader, train_state_shape.params.to_pure_dict())
    replicated_sharding = jax.sharding.NamedSharding(mesh, jax.sharding.PartitionSpec())

    # Initialize the train state and mix in the partial params.
    train_state = jax.jit(
        init,
        donate_argnums=(1,),  # donate the partial params buffer.
        in_shardings=replicated_sharding,
        out_shardings=state_sharding,
    )(init_rng, partial_params)

    return train_state, state_sharding


@at.typecheck
def train_step(
    config: _config.TrainConfig,
    rng: at.KeyArrayLike,
    state: training_utils.TrainState,
    batch: tuple[_model.Observation, _model.Actions],
) -> tuple[training_utils.TrainState, dict[str, at.Array]]:
    model = nnx.merge(state.model_def, state.params)
    model.train()

    @at.typecheck
    def loss_fn(
        model: _model.BaseModel, rng: at.KeyArrayLike, observation: _model.Observation, actions: _model.Actions
    ):
        chunked_loss = model.compute_loss(rng, observation, actions, train=True)
        return jnp.mean(chunked_loss)

    train_rng = jax.random.fold_in(rng, state.step)
    observation, actions = batch

    # Filter out frozen params.
    diff_state = nnx.DiffState(0, config.trainable_filter)
    if config.gradient_accumulation_steps == 1:
        loss, grads = nnx.value_and_grad(loss_fn, argnums=diff_state)(model, train_rng, observation, actions)
    else:
        accumulation_steps = config.gradient_accumulation_steps
        if actions.shape[0] % accumulation_steps:
            raise ValueError("Effective batch must divide evenly into accumulated microbatches.")
        microbatches = jax.tree.map(
            lambda x: x.reshape((accumulation_steps, x.shape[0] // accumulation_steps, *x.shape[1:])),
            (observation, actions),
        )
        keys = jax.random.split(train_rng, accumulation_steps)
        zero_grads = jax.tree.map(jnp.zeros_like, state.params.filter(config.trainable_filter))

        def accumulate(carry, inputs):
            loss_sum, grad_sum = carry
            key, (micro_observation, micro_actions) = inputs
            micro_model = nnx.merge(state.model_def, state.params)
            micro_model.train()
            micro_loss, micro_grads = nnx.value_and_grad(loss_fn, argnums=diff_state)(
                micro_model, key, micro_observation, micro_actions,
            )
            return (loss_sum + micro_loss, jax.tree.map(jnp.add, grad_sum, micro_grads)), None

        (loss_sum, grad_sum), _ = jax.lax.scan(
            accumulate, (jnp.zeros((), dtype=jnp.float32), zero_grads), (keys, microbatches),
        )
        loss = loss_sum / accumulation_steps
        grads = jax.tree.map(lambda x: x / accumulation_steps, grad_sum)

    params = state.params.filter(config.trainable_filter)
    updates, new_opt_state = state.tx.update(grads, state.opt_state, params)
    new_params = optax.apply_updates(params, updates)

    # Update the model in place and return the new full state.
    nnx.update(model, new_params)
    new_params = nnx.state(model)

    new_state = dataclasses.replace(state, step=state.step + 1, params=new_params, opt_state=new_opt_state)
    if state.ema_decay is not None:
        new_state = dataclasses.replace(
            new_state,
            ema_params=jax.tree.map(
                lambda old, new: state.ema_decay * old + (1 - state.ema_decay) * new, state.ema_params, new_params
            ),
        )

    # Filter out params that aren't kernels.
    kernel_params = nnx.state(
        model,
        nnx.All(
            nnx.Param,
            nnx.Not(nnx_utils.PathRegex(".*/(bias|scale|pos_embedding|input_embedding)")),
            lambda _, x: x.value.ndim > 1,
        ),
    )
    info = {
        "loss": loss,
        "grad_norm": optax.global_norm(grads),
        "param_norm": optax.global_norm(kernel_params),
    }
    return new_state, info


def resolve_epoch_warmup(config: _config.TrainConfig) -> _config.TrainConfig:
    if config.warmup_epochs is None:
        return config
    if not math.isfinite(config.warmup_epochs) or config.warmup_epochs < 0 or config.batch_size <= 0:
        raise ValueError("warmup_epochs must be finite and non-negative, and batch_size must be positive.")
    if not isinstance(config.lr_schedule, _optimizer.CosineDecaySchedule):
        raise ValueError("Epoch warmup currently requires CosineDecaySchedule.")
    repo_id = config.data.repo_id
    if not repo_id or repo_id == "fake":
        raise ValueError("Epoch warmup requires a LeRobot dataset with frame-count metadata.")
    total_frames = LeRobotDatasetMetadata(repo_id).total_frames
    if total_frames <= 0:
        raise ValueError("Epoch warmup requires a non-empty dataset.")
    warmup_steps = math.ceil(config.warmup_epochs * total_frames / config.batch_size)
    if warmup_steps >= config.lr_schedule.decay_steps:
        raise ValueError("Resolved warmup_steps must be smaller than decay_steps.")
    logging.info("EPOCH_WARMUP epochs=%g frames=%d global_batch=%d warmup_steps=%d",
                 config.warmup_epochs, total_frames, config.batch_size, warmup_steps)
    return dataclasses.replace(config, lr_schedule=dataclasses.replace(config.lr_schedule, warmup_steps=warmup_steps))


def resolve_epochs(config: _config.TrainConfig) -> _config.TrainConfig:
    if config.num_epochs is None:
        return config
    if config.num_epochs <= 0 or config.batch_size <= 0:
        raise ValueError("num_epochs and batch_size must be positive.")
    if not isinstance(config.lr_schedule, _optimizer.CosineDecaySchedule):
        raise ValueError("Epoch training currently requires CosineDecaySchedule.")
    total_frames = LeRobotDatasetMetadata(config.data.repo_id).total_frames
    if total_frames < config.batch_size:
        raise ValueError("Epoch training requires at least one full batch.")
    tail = total_frames % config.batch_size
    if tail % jax.device_count():
        raise ValueError("The final batch must be divisible by the number of GPUs.")
    steps_per_epoch = math.ceil(total_frames / config.batch_size)
    total_steps = steps_per_epoch * config.num_epochs
    logging.info("EPOCH_PLAN epochs=%d frames_per_epoch=%d steps_per_epoch=%d tail_batch=%d total_steps=%d",
                 config.num_epochs, total_frames, steps_per_epoch, tail, total_steps)
    return dataclasses.replace(
        config, num_train_steps=total_steps, save_interval=steps_per_epoch, keep_period=steps_per_epoch,
        lr_schedule=dataclasses.replace(config.lr_schedule, decay_steps=total_steps),
    )


def publish_epoch(config: _config.TrainConfig, epoch: int, completed_steps: int) -> None:
    """Publish an inference-ready alias only after Orbax finishes the checkpoint."""
    root = pathlib.Path(config.checkpoint_dir)
    checkpoint = root / str(completed_steps)
    if not (checkpoint / "params" / "_METADATA").exists():
        raise RuntimeError(f"Checkpoint is not ready: {checkpoint}")
    (root / f"epoch_{epoch:03d}").symlink_to(str(completed_steps), target_is_directory=True)
    ready = {"epoch": epoch, "completed_steps": completed_steps, "checkpoint": str(checkpoint),
             "ready_at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}
    (root / f"epoch_{epoch:03d}.ready.json").write_text(json.dumps(ready, indent=2) + "\n")
    logging.info("EPOCH_READY %s", json.dumps(ready))


def main(config: _config.TrainConfig):
    init_logging()
    config = resolve_epochs(config)
    config = resolve_epoch_warmup(config)
    logging.info(f"Running on: {platform.node()}")

    accumulation_steps = config.gradient_accumulation_steps
    if accumulation_steps < 1 or config.batch_size % (accumulation_steps * jax.device_count()):
        raise ValueError("Effective batch must divide evenly across GPUs and accumulation steps.")
    if accumulation_steps > 1 and jax.device_count() != 1:
        raise ValueError("Gradient accumulation is currently supported on one GPU only.")
    if config.num_epochs is not None:
        tail = LeRobotDatasetMetadata(config.data.repo_id).total_frames % config.batch_size
        if tail % accumulation_steps:
            raise ValueError("Tail batch must divide evenly into accumulated microbatches.")

    if config.batch_size % jax.device_count() != 0:
        raise ValueError(
            f"Batch size {config.batch_size} must be divisible by the number of devices {jax.device_count()}."
        )

    jax.config.update("jax_compilation_cache_dir", str(epath.Path("~/.cache/jax").expanduser()))

    rng = jax.random.key(config.seed)
    train_rng, init_rng = jax.random.split(rng)

    mesh = sharding.make_mesh(config.fsdp_devices)
    logging.info("DEVICE_LAYOUT devices=%s mesh=%s global_batch=%d per_device_effective_batch=%d",
                 jax.devices(), mesh.shape, config.batch_size, config.batch_size // jax.device_count())
    logging.info("BATCH_LAYOUT effective_batch=%d micro_batch_per_device=%d gradient_accumulation_steps=%d",
                 config.batch_size, config.batch_size // jax.device_count() // accumulation_steps, accumulation_steps)
    data_sharding = jax.sharding.NamedSharding(mesh, jax.sharding.PartitionSpec(sharding.DATA_AXIS))
    replicated_sharding = jax.sharding.NamedSharding(mesh, jax.sharding.PartitionSpec())

    checkpoint_manager, resuming = _checkpoints.initialize_checkpoint_dir(
        config.checkpoint_dir,
        keep_period=config.keep_period,
        overwrite=config.overwrite,
        resume=config.resume,
    )
    init_wandb(config, resuming=resuming, enabled=config.wandb_enabled)
    restore_step = checkpoint_manager.latest_step() if resuming else None
    start_epoch = 0
    if resuming and config.num_epochs is not None:
        if restore_step is None or restore_step % config.save_interval:
            raise ValueError("Exact-epoch resume requires a completed epoch checkpoint.")
        start_epoch = restore_step // config.save_interval
        if restore_step >= config.num_train_steps:
            raise ValueError("The requested training epochs are already complete.")
        previous = json.loads((pathlib.Path(config.checkpoint_dir) / "run_config.json").read_text())
        current = json.loads(json.dumps(dataclasses.asdict(config), default=str))
        for key in ("model", "data", "batch_size", "num_workers", "seed", "lr_schedule", "optimizer",
                    "ema_decay", "num_epochs", "num_train_steps", "save_interval"):
            if current[key] != previous[key]:
                raise ValueError(f"Resume would change the original training setting: {key}")
    if config.num_epochs is not None:
        config_name = f"run_config_resume_{time.strftime('%Y%m%d_%H%M%S')}.json" if resuming else "run_config.json"
        (pathlib.Path(config.checkpoint_dir) / config_name).write_text(
            json.dumps(dataclasses.asdict(config), default=str, indent=2) + "\n"
        )

    data_loader = _data_loader.create_data_loader(
        config,
        sharding=data_sharding,
        shuffle=True,
        start_epoch=start_epoch,
    )
    data_iter = iter(data_loader)
    batch = next(data_iter)
    logging.info(f"Initialized data loader:\n{training_utils.array_tree_to_info(batch)}")

    # Log images from first batch to sanity check.
    images_to_log = [
        wandb.Image(np.concatenate([np.array(img[i]) for img in batch[0].images.values()], axis=1))
        for i in range(min(5, len(next(iter(batch[0].images.values())))))
    ]
    wandb.log({"camera_views": images_to_log}, step=0)

    train_state, train_state_sharding = init_train_state(config, init_rng, mesh, resume=resuming)
    if resuming:
        train_state = _checkpoints.restore_state(
            checkpoint_manager, train_state, data_loader, step=restore_step, state_sharding=train_state_sharding,
        )
        if int(train_state.step) != restore_step:
            raise ValueError("Optimizer step does not match the completed checkpoint step.")
        logging.info("RESUMED step=%d completed_epochs=%d learning_rate=%.9g", int(train_state.step),
                     start_epoch, float(config.lr_schedule.create()(train_state.step)))
    jax.block_until_ready(train_state)
    logging.info("PARAMETER_COUNTS total=%d trainable=%d",
                 sum(x.size for x in jax.tree.leaves(train_state.params)),
                 sum(x.size for x in jax.tree.leaves(train_state.params.filter(config.trainable_filter))))
    logging.info(f"Initialized train state:\n{training_utils.array_tree_to_info(train_state.params)}")

    ptrain_step = jax.jit(
        functools.partial(train_step, config),
        in_shardings=(replicated_sharding, train_state_sharding, data_sharding),
        out_shardings=(train_state_sharding, replicated_sharding),
        donate_argnums=(1,),
    )

    start_step = int(train_state.step)
    pbar = tqdm.tqdm(
        range(start_step, config.num_train_steps),
        initial=start_step,
        total=config.num_train_steps,
        dynamic_ncols=True,
    )

    infos = []
    for step in pbar:
        step_started = time.perf_counter()
        with sharding.set_mesh(mesh):
            train_state, info = ptrain_step(train_rng, train_state, batch)
        infos.append(info)
        if step % config.log_interval == 0:
            stacked_infos = common_utils.stack_forest(infos)
            reduced_info = jax.device_get(jax.tree.map(jnp.mean, stacked_infos))
            if not all(np.isfinite(value).all() for value in reduced_info.values()):
                raise FloatingPointError(f"Non-finite training metrics at step {step}: {reduced_info}")
            info_str = ", ".join(f"{k}={v:.4f}" for k, v in reduced_info.items())
            pbar.write(f"Step {step}: {info_str}")
            wandb.log(reduced_info, step=step)
            infos = []
        if config.log_interval == 1:
            # device_get above synchronizes the step.
            logging.info("STEP_TIMING step=%d seconds=%.6f", step, time.perf_counter() - step_started)

        if config.num_epochs is not None and (step + 1) % config.save_interval == 0:
            _checkpoints.save_state(checkpoint_manager, train_state, data_loader, step + 1)
            checkpoint_manager.wait_until_finished()
            publish_epoch(config, (step + 1) // config.save_interval, step + 1)
        elif config.num_epochs is None and (
            (step % config.save_interval == 0 and step > start_step) or step == config.num_train_steps - 1
        ):
            _checkpoints.save_state(checkpoint_manager, train_state, data_loader, step)
        if step + 1 < config.num_train_steps:
            batch = next(data_iter)

    logging.info("Waiting for checkpoint manager to finish")
    checkpoint_manager.wait_until_finished()
    for device in jax.local_devices():
        logging.info("DEVICE_MEMORY device=%s stats=%s", device, device.memory_stats())


if __name__ == "__main__":
    main(_config.cli())
