#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
source ./runtime/environment.sh
exec "$PIPERX_NATIVE_PYTHON" -u train.py "$@"
