from pathlib import Path
import argparse, importlib.metadata, json, sys
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from runtime import bootstrap, load_settings
p = argparse.ArgumentParser()
p.add_argument('--config', type=Path, default=root / 'config.json')
p.add_argument('--gpu', action='store_true')
a = p.parse_args()
c = load_settings(a.config)
bootstrap(c, cpu=not a.gpu)
import av, pyarrow, jax
from train import build_config
for name in ['jax','flax','torch','av','pyarrow','orbax-checkpoint']:
    print(name, importlib.metadata.version(name))
print('Devices:', jax.devices())
print('Dataset exists:', Path(c['source_root']).is_dir())
print('Base params exist:', (Path(c['base_params']) / '_METADATA').is_file())
print('Imports passed; no optimizer updates executed.')
