from pathlib import Path
import hashlib, json, os, shlex, sys
root = Path(__file__).resolve().parents[1]
assert sys.version_info[:2] == (3, 11), "Use Python 3.11"
record = json.loads((root / "runtime/source_manifest.json").read_text())
for name, expected in record["files"].items():
    actual = hashlib.sha256((root / "runtime/openpi" / name).read_bytes()).hexdigest()
    assert actual == expected, f"OpenPI snapshot mismatch: {name}"
python = os.environ.get("PIPERX_NATIVE_PYTHON", str(root / ".venv/bin/python"))
assert Path(python).is_file(), python
# A normal bundled environment stays relocatable; --reuse intentionally points at the supplied interpreter.
default_python = '"$_piperx_root/.venv/bin/python"' if Path(python) == root / '.venv/bin/python' else shlex.quote(python)
lines = [
    '_piperx_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")/.." && pwd)"',
    'if [[ -z "${PIPERX_NATIVE_PYTHON:-}" ]]; then export PIPERX_NATIVE_PYTHON=' + default_python + '; fi',
    'export HF_HOME="${HF_HOME:-$_piperx_root/cache/huggingface}"',
    'export OPENPI_DATA_HOME="${OPENPI_DATA_HOME:-$_piperx_root/cache/openpi}"',
    'export HF_HUB_DISABLE_TELEMETRY=1',
    'export OMP_NUM_THREADS=1',
    'export OPENBLAS_NUM_THREADS=1',
    'export PYTHONDONTWRITEBYTECODE=1',
    'unset _piperx_root',
]
(root / 'runtime/environment.sh').write_text('\n'.join(lines) + '\n')
print('Configured Python:', python)
