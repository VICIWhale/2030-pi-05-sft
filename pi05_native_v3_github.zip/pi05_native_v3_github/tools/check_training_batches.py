"""Validate actual normalized full/tail batches without model training."""
from pathlib import Path
import argparse
import functools
import math
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def main():
    from runtime import load_settings, bootstrap, read_json, write_json
    p = argparse.ArgumentParser()
    p.add_argument("--config", type=Path, required=True)
    a = p.parse_args()
    c = load_settings(a.config)
    bootstrap(c, cpu=True)
    import numpy as np
    import torch
    from dataset import NativeDataset, EpochBatches, collate
    from train import build_config, data_config_and_transform
    m = read_json(ROOT / "reports/check_manifest.json")
    cfg = build_config(c, m, "preflight_only")
    dc, transform = data_config_and_transform(cfg, m)
    ds = NativeDataset(m, c["action_horizon"], transform)
    per_epoch = math.ceil(len(ds) / c["batch_size"])
    indices = list(EpochBatches(len(ds), c["batch_size"], c["seed"], 0, per_epoch))
    assert sorted(sum(indices, [])) == list(range(len(ds)))
    chosen = [indices[0], indices[1], indices[-1]]
    started = time.perf_counter()
    loader = torch.utils.data.DataLoader(ds, batch_sampler=chosen, num_workers=c["num_workers"],
        multiprocessing_context="spawn" if c["num_workers"] else None,
        collate_fn=functools.partial(collate, multiple=len(c["gpu_ids"].split(",")) * c["gradient_accumulation_steps"]))
    rows = []
    for number, batch in enumerate(loader):
        n = len(chosen[number])
        mask = batch["sample_mask"]
        assert int(mask.sum()) == n
        assert batch["actions"].shape == (len(mask), c["action_horizon"], 32)
        assert np.isfinite(batch["actions"]).all() and np.isfinite(batch["state"]).all()
        assert all(im.shape == (len(mask), 224, 224, 3) and np.isfinite(im).all() for im in batch["image"].values())
        row = {"batch": number, "real_samples": n, "padded_samples": len(mask), "actions_shape": list(batch["actions"].shape),
               "token_shape": list(batch["tokenized_prompt"].shape), "all_finite": True}
        rows.append(row)
        print(row, flush=True)
    ds.close()
    report = {"data_fingerprint": m["fingerprint"], "batches": rows, "wall_seconds": time.perf_counter() - started,
              "epoch_real_sample_coverage": len(ds), "source_episodes": len(m["episodes"]), "optimizer_updates": 0, "passed": True}
    write_json(ROOT / "reports/full122_batch_check.json", report)
    print("TRAINING_BATCH_CHECK_PASSED", flush=True)


if __name__ == "__main__":
    main()
