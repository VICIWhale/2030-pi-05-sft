"""Full native-v3 integrity check using bounded parallel video decoding."""
from pathlib import Path
import sys
import argparse
import concurrent.futures
import multiprocessing
from collections import OrderedDict

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))


def check_video(job):
    import av
    import numpy as np
    from dataset import NativeDataset, require
    from openpi_client.image_tools import resize_with_pad
    file, count, fps = job
    targets = {0, count // 2, count - 1}
    reference = {}
    decoded = 0
    with av.open(file) as container:
        stream = container.streams.video[0]
        stream.codec_context.thread_count = 1
        for index, frame in enumerate(container.decode(stream)):
            require(frame.time is not None and abs(frame.time - index / fps) < 0.5 / fps,
                    f"{file}: timestamp mismatch at frame {index}")
            if index in targets:
                reference[index] = resize_with_pad(frame.to_ndarray(format="rgb24"), 224, 224).transpose(2, 0, 1)
            decoded += 1
    require(decoded == count, f"{file}: decoded {decoded}, expected {count}")
    # Exercise the actual training reader against the sequentially decoded frames.
    reader = NativeDataset.__new__(NativeDataset)
    reader.manifest = {"fps": fps}
    reader._containers = OrderedDict()
    try:
        for index in sorted(targets, reverse=True):
            np.testing.assert_array_equal(reader.image(file, index), reference[index])
    finally:
        reader.close()
    return {"file": file, "frames": decoded, "random_access_checks": len(targets)}


def main():
    from runtime import load_settings, bootstrap, write_json
    p = argparse.ArgumentParser()
    p.add_argument("--config", type=Path, required=True)
    p.add_argument("--workers", type=int, default=8)
    a = p.parse_args()
    if not 1 <= a.workers <= 32:
        p.error("workers must be 1..32")
    c = load_settings(a.config)
    bootstrap(c, cpu=True)
    from dataset import scan
    m = scan(c)
    jobs = [(str(Path(m["source_root"]) / file), e["frames"], m["fps"])
            for e in m["episodes"] for file in e["videos"].values()]
    results = []
    with concurrent.futures.ProcessPoolExecutor(max_workers=a.workers,
            mp_context=multiprocessing.get_context("spawn")) as pool:
        futures = [pool.submit(check_video, j) for j in jobs]
        for f in concurrent.futures.as_completed(futures):
            results.append(f.result())
            if len(results) % 12 == 0 or len(results) == len(jobs):
                print(f"VIDEOS_CHECKED {len(results)}/{len(jobs)}", flush=True)
    m["full_video_verified"] = True
    write_json(ROOT / "reports/check_manifest.json", m)
    write_json(ROOT / "reports/check_result.json", {"all_videos_decoded": True,
        "random_access_boundary_checks": True, "fingerprint": m["fingerprint"], **m["summary"],
        "videos": len(results), "decoded_video_frames": sum(r["frames"] for r in results),
        "random_access_checks": sum(r["random_access_checks"] for r in results),
        "method": "parallel full decode + exact first/middle/last pixel comparison"})
    print("CHECK_PASSED " + str(m["summary"]), flush=True)


if __name__ == "__main__":
    main()
