"""π0.5 LoRA on the original PiperX LeRobot v3 MP4/Parquet recordings."""
import argparse
import dataclasses
import datetime
import functools
import json
import logging
import math
from pathlib import Path
import time

from runtime import ROOT, bootstrap, code_fingerprint, load_settings, read_json, write_json, digest


def build_config(c, manifest, experiment):
    from openpi.models import pi0_config
    from openpi.training import config, optimizer, weight_loaders
    model = pi0_config.Pi0Config(pi05=True, action_dim=32, action_horizon=c["action_horizon"],
                               paligemma_variant="gemma_2b_lora", action_expert_variant="gemma_300m_lora")
    steps_per_epoch = math.ceil(manifest["summary"]["frames"] / c["batch_size"])
    total_steps = steps_per_epoch * c["epochs"]
    if total_steps < 2:
        raise ValueError("Need at least two updates")
    warmup = min(total_steps - 1, math.ceil(c["warmup_epochs"] * steps_per_epoch))
    asset_id = manifest["fingerprint"]
    return config.TrainConfig(
        name="pi05_piperx_native_v3_lora", exp_name=experiment, model=model,
        data=config.LeRobotAlohaDataConfig(repo_id="native_v3", adapt_to_pi=False, use_delta_joint_actions=True,
            assets=config.AssetsConfig(asset_id=asset_id)),
        assets_base_dir=str(ROOT / "assets"), checkpoint_base_dir=str(ROOT / "checkpoints"),
        weight_loader=weight_loaders.CheckpointWeightLoader(c["base_params"]), freeze_filter=model.get_freeze_filter(),
        lr_schedule=optimizer.CosineDecaySchedule(warmup_steps=warmup, peak_lr=c["learning_rate"],
            decay_steps=total_steps, decay_lr=c["learning_rate"] / 10),
        optimizer=optimizer.AdamW(clip_gradient_norm=1.0), ema_decay=None,
        batch_size=c["batch_size"], gradient_accumulation_steps=c["gradient_accumulation_steps"],
        num_workers=c["num_workers"], seed=c["seed"], num_train_steps=total_steps, log_interval=c["log_interval"],
        save_interval=steps_per_epoch, keep_period=steps_per_epoch, wandb_enabled=False, fsdp_devices=1,
        policy_metadata={"dataset_format": "PiperX recorder LeRobot v3.0", "training_fps": c["fps"],
            "action_horizon": c["action_horizon"], "joint_order": "left6,left_gripper,right6,right_gripper",
            "units": "joint=rad, gripper opening=m", "language_rank": c["language_rank"], "action_rank": c["action_rank"]})


def stats_path(cfg, manifest):
    return Path(cfg.assets_dirs) / manifest["fingerprint"]


def compute_stats(c, manifest, cfg):
    import numpy as np
    from dataset import NativeDataset, JOINT_MASK
    from openpi.shared import normalize
    ds = NativeDataset(manifest, c["action_horizon"])
    state_stats, action_stats = normalize.RunningStats(), normalize.RunningStats()
    for state, action in ds.signals:
        for start in range(0, len(state), 2048):
            frames = np.arange(start, min(start + 2048, len(state)))
            indices = np.minimum(frames[:, None] + np.arange(c["action_horizon"]), len(state) - 1)
            targets = action[indices].astype(np.float64)
            targets[:, :, JOINT_MASK] -= state[frames][:, None, JOINT_MASK]
            state_stats.update(state[frames].astype(np.float64))
            action_stats.update(targets)
    path = stats_path(cfg, manifest)
    normalize.save(path, {"state": state_stats.get_statistics(), "actions": action_stats.get_statistics()})
    write_json(path / "source.json", {"fingerprint": manifest["fingerprint"], "action_horizon": c["action_horizon"],
                                     "frames": len(ds), "norm_stats_sha256": digest(path / "norm_stats.json")})
    print(f"STATS {path}", flush=True)


def data_config_and_transform(cfg, manifest):
    from openpi import transforms
    from openpi.shared import normalize
    path = stats_path(cfg, manifest)
    receipt = read_json(path / "source.json")
    if receipt["fingerprint"] != manifest["fingerprint"] or receipt["norm_stats_sha256"] != digest(path / "norm_stats.json"):
        raise ValueError("Normalization fingerprint mismatch: run stats")
    dc = dataclasses.replace(cfg.data.create(cfg.assets_dirs, cfg.model), norm_stats=normalize.load(path))
    transform = transforms.compose([*dc.data_transforms.inputs,
        transforms.Normalize(dc.norm_stats, use_quantiles=dc.use_quantile_norm), *dc.model_transforms.inputs])
    return dc, transform


def weighted_loss(per_sample, mask, denominator):
    import jax.numpy as jnp
    return jnp.sum(per_sample * mask) / denominator


def train_step(cfg, augment, rng, state, batch):
    """OpenPI flow-matching objective, with weighted tails and accumulation."""
    import flax.nnx as nnx
    import jax
    import jax.numpy as jnp
    import optax
    obs, actions, mask = batch
    denominator = mask.sum()
    model = nnx.merge(state.model_def, state.params)
    model.train()
    def loss_fn(m, key, observation, target, weights):
        loss = m.compute_loss(key, observation, target, train=augment)
        per_sample = loss.reshape((loss.shape[0], -1)).mean(axis=1)
        return weighted_loss(per_sample, weights, denominator)
    key = jax.random.fold_in(rng, state.step)
    diff = nnx.DiffState(0, cfg.trainable_filter)
    steps = cfg.gradient_accumulation_steps
    if steps == 1:
        loss, grads = nnx.value_and_grad(loss_fn, argnums=diff)(model, key, obs, actions, mask)
    else:
        parts = jax.tree.map(lambda x: x.reshape((steps, x.shape[0] // steps, *x.shape[1:])), batch)
        zero = jax.tree.map(jnp.zeros_like, state.params.filter(cfg.trainable_filter))
        def accumulate(carry, inputs):
            loss_sum, grad_sum = carry
            subkey, (subobs, subactions, submask) = inputs
            submodel = nnx.merge(state.model_def, state.params)
            submodel.train()
            loss, grad = nnx.value_and_grad(loss_fn, argnums=diff)(submodel, subkey, subobs, subactions, submask)
            return (loss_sum + loss, jax.tree.map(jnp.add, grad_sum, grad)), None
        (loss, grads), _ = jax.lax.scan(accumulate, (jnp.zeros((), jnp.float32), zero), (jax.random.split(key, steps), parts))
    params = state.params.filter(cfg.trainable_filter)
    updates, opt_state = state.tx.update(grads, state.opt_state, params)
    nnx.update(model, optax.apply_updates(params, updates))
    new_state = dataclasses.replace(state, step=state.step + 1, params=nnx.state(model), opt_state=opt_state)
    return new_state, {"loss": loss, "grad_norm": optax.global_norm(grads), "real_samples": denominator}


class CheckpointAssets:
    def __init__(self, config):
        self.config = config

    def data_config(self):
        return self.config


def run_training(c, manifest, cfg, args):
    from progress import Progress
    # Add the per-experiment report only after the existing-directory guard.
    progress = Progress([ROOT / 'reports/训练进度.md', ROOT.parent / 'π0.5训练进度.md'], cfg.exp_name,
                        cfg.save_interval, c['epochs'], cfg.checkpoint_dir, c)
    progress.start()
    try:
        _run_training(c, manifest, cfg, args, progress)
    except BaseException as exc:
        progress.finish('已中断' if isinstance(exc, KeyboardInterrupt) else '训练失败',
                        f'{type(exc).__name__}: {exc}')
        raise


def _run_training(c, manifest, cfg, args, progress):
    import fcntl
    import jax
    import numpy as np
    import torch
    from dataset import NativeDataset, EpochBatches, collate
    from openpi.models import model as model_lib
    from openpi.training import checkpoints, sharding
    from scripts.train import init_train_state
    checked = read_json(ROOT / "reports/check_result.json")
    if checked["fingerprint"] != manifest["fingerprint"] or not checked["all_videos_decoded"]:
        raise ValueError("Run check for these source files before training")
    if jax.device_count() != len(c["gpu_ids"].split(",")) or any(d.platform != "gpu" for d in jax.devices()):
        raise RuntimeError(f"GPU layout mismatch: {jax.devices()}")
    # Per-GPU advisory locks prevent two launches of this project on the same card.
    locks = []
    for gpu in sorted(c["gpu_ids"].split(",")):
        f = (ROOT / "runtime" / f"gpu_{gpu}.lock").open("a")
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        locks.append(f)
    dc, transform = data_config_and_transform(cfg, manifest)
    record = {"settings": c, "data_fingerprint": manifest["fingerprint"], "code": code_fingerprint(),
              "norm_stats_sha256": digest(stats_path(cfg, manifest) / "norm_stats.json")}
    checkpoint_dir = Path(cfg.checkpoint_dir)
    if args.resume:
        old = read_json(checkpoint_dir / "run.json")
        if old != record:
            raise ValueError("Resume requires identical data, code and settings; create a new experiment for changes")
    elif checkpoint_dir.exists():
        raise FileExistsError(f"Experiment exists: {checkpoint_dir}")
    manager, resuming = checkpoints.initialize_checkpoint_dir(checkpoint_dir, keep_period=cfg.save_interval, overwrite=False, resume=args.resume)
    if args.resume and not resuming:
        raise RuntimeError("No completed checkpoint available to resume")
    if not args.resume:
        write_json(checkpoint_dir / "run.json", record)
        write_json(checkpoint_dir / "dataset.json", manifest)
    progress.paths.append(checkpoint_dir / 'progress.md')
    start = int(manager.latest_step()) if resuming else 0
    stop = cfg.num_train_steps if args.stop_after_step is None else min(args.stop_after_step, cfg.num_train_steps)
    if stop <= start:
        raise ValueError(f"No remaining requested updates: start={start}, stop={stop}")
    ds = NativeDataset(manifest, c["action_horizon"], transform)
    batches = EpochBatches(len(ds), c["batch_size"], c["seed"], start, stop)
    loader = torch.utils.data.DataLoader(ds, batch_sampler=batches, num_workers=c["num_workers"],
        multiprocessing_context="spawn" if c["num_workers"] else None,
        persistent_workers=c["num_workers"] > 0,
        collate_fn=functools.partial(collate, multiple=jax.device_count() * c["gradient_accumulation_steps"]))
    mesh = sharding.make_mesh(cfg.fsdp_devices)
    data_shard = jax.sharding.NamedSharding(mesh, jax.sharding.PartitionSpec(sharding.DATA_AXIS))
    replicated = jax.sharding.NamedSharding(mesh, jax.sharding.PartitionSpec())
    train_rng, init_rng = jax.random.split(jax.random.key(c["seed"]))
    logging.info("Initializing model: GPUs=%s, ranks=%s/%s, frames=%s, steps/epoch=%s, total=%s", jax.devices(), c["language_rank"], c["action_rank"], len(ds), cfg.save_interval, cfg.num_train_steps)
    state, state_shard = init_train_state(cfg, init_rng, mesh, resume=resuming)
    assets = CheckpointAssets(dc)
    if resuming:
        state = checkpoints.restore_state(manager, state, assets, step=start, state_sharding=state_shard)
        if int(state.step) != start:
            raise ValueError("Restored optimizer step mismatch")
    jax.block_until_ready(state)
    logging.info("PARAMETERS total=%s trainable=%s restored_step=%s", sum(x.size for x in jax.tree.leaves(state.params)), sum(x.size for x in jax.tree.leaves(state.params.filter(cfg.trainable_filter))), start)
    update = jax.jit(functools.partial(train_step, cfg, c["image_augmentation"]),
        in_shardings=(replicated, state_shard, data_shard), out_shardings=(state_shard, replicated), donate_argnums=(1,))
    progress.resume(start)
    log_path = checkpoint_dir / "metrics.jsonl"
    with log_path.open("a", buffering=1) as log:
        for expected_step, batch in enumerate(loader, start=start + 1):
            began = time.perf_counter()
            batch = jax.tree.map(lambda x: jax.make_array_from_process_local_data(data_shard, x), batch)
            obs = model_lib.Observation.from_dict(batch)
            with sharding.set_mesh(mesh):
                state, info = update(train_rng, state, (obs, batch["actions"], batch["sample_mask"]))
            info = {k: float(v) for k, v in jax.device_get(info).items()}
            if not all(math.isfinite(v) for v in info.values()):
                raise FloatingPointError(f"Non-finite metrics: {info}")
            row = {"step": expected_step, "epoch": (expected_step - 1) // cfg.save_interval + 1,
                   "loss": info["loss"], "grad_norm": info["grad_norm"], "real_samples": int(info["real_samples"]),
                   "update_seconds": time.perf_counter() - began,
                   "learning_rate": float(cfg.lr_schedule.create()(expected_step - 1)),
                   "time": datetime.datetime.now().astimezone().isoformat()}
            log.write(json.dumps(row) + "\n")
            progress.update(row)
            if expected_step == start + 1 or expected_step % c["log_interval"] == 0 or expected_step == stop:
                print(json.dumps(row), flush=True)
            if expected_step % cfg.save_interval == 0 or expected_step == stop:
                progress.phase('保存 checkpoint 中')
                checkpoints.save_state(manager, state, assets, expected_step)
                manager.wait_until_finished()
                write_json(checkpoint_dir / f"{expected_step}.ready.json", {"step": expected_step, "completed_epochs": expected_step // cfg.save_interval, "checkpoint": str(checkpoint_dir / str(expected_step))})
                print(f"CHECKPOINT_READY {expected_step}", flush=True)
                progress.phase('训练中', latest_checkpoint_step=expected_step,
                               latest_checkpoint=str(checkpoint_dir / str(expected_step)))
    manager.wait_until_finished()
    manager.close()
    ds.close()
    status = "complete" if stop == cfg.num_train_steps else "paused_after_requested_step"
    write_json(checkpoint_dir / "status.json", {"status": status, "completed_steps": stop, "planned_steps": cfg.num_train_steps})
    progress.finish('训练完成' if status == 'complete' else '已按要求保存并暂停')
    print(f"TRAINING_EXIT {status} step={stop}", flush=True)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("command", choices=["scan", "check", "stats", "train", "serve"])
    p.add_argument("--config", type=Path, default=ROOT / "config.json")
    p.add_argument("--experiment", default=None)
    p.add_argument("--resume", action="store_true")
    p.add_argument("--stop-after-step", type=int, help="Save and pause after this global update; keeps original LR schedule")
    p.add_argument("--checkpoint", type=Path)
    p.add_argument("--port", type=int, default=8001)
    a = p.parse_args()
    c = load_settings(a.config)
    bootstrap(c, cpu=a.command in ("scan", "check", "stats"))
    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
    if a.command == "serve":
        if a.checkpoint is None:
            p.error("serve requires --checkpoint")
        checkpoint = a.checkpoint.resolve()
        saved = read_json(checkpoint.parent / "run.json")
        saved_c = saved["settings"]
        # Serving can select a different GPU, but model ranks come from the training record.
        saved_c["gpu_ids"] = c["gpu_ids"]
        bootstrap(saved_c)
        manifest = read_json(checkpoint.parent / "dataset.json")
        cfg = build_config(saved_c, manifest, checkpoint.parent.name)
        from openpi.policies.policy_config import create_trained_policy
        from openpi.serving.websocket_policy_server import WebsocketPolicyServer
        policy = create_trained_policy(cfg, checkpoint)
        WebsocketPolicyServer(policy, host="0.0.0.0", port=a.port, metadata={**policy.metadata, "checkpoint": str(checkpoint)}).serve_forever()
        return
    from dataset import scan, NativeDataset
    manifest = scan(c, full_video=a.command == "check")
    write_json(ROOT / "reports" / f"{a.command}_manifest.json", manifest)
    print(json.dumps(manifest["summary"], ensure_ascii=False), flush=True)
    if a.command == "scan":
        return
    experiment = a.experiment or datetime.datetime.now().strftime("native_%Y%m%d_%H%M%S")
    if Path(experiment).name != experiment or experiment in (".", ".."):
        p.error("experiment must be a simple directory name")
    if a.resume and not a.experiment:
        p.error("resume requires --experiment")
    cfg = build_config(c, manifest, experiment)
    if a.command == "stats":
        compute_stats(c, manifest, cfg)
    elif a.command == "check":
        ds = NativeDataset(manifest, c["action_horizon"])
        for end, ep in zip(ds.ends, manifest["episodes"]):
            for i in [end - ep["frames"], end - ep["frames"] // 2 - 1, end - 1]:
                sample = ds[i]
                assert sample["actions"].shape == (c["action_horizon"], 14)
                assert all(im.shape == (3, 224, 224) for im in sample["images"].values())
        ds.close()
        write_json(ROOT / "reports/check_result.json", {"all_videos_decoded": True, "random_access_boundary_checks": True, "fingerprint": manifest["fingerprint"], **manifest["summary"]})
        print("CHECK_PASSED: full video timestamps/counts and first/middle/last observations")
    else:
        run_training(c, manifest, cfg, a)


if __name__ == "__main__":
    main()
