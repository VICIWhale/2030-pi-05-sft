"""Checks boundary isolation, sample coverage, video alignment and masked gradients."""
import unittest
from pathlib import Path
import numpy as np
from runtime import ROOT, bootstrap, load_settings, write_json

C = load_settings(ROOT / 'config.json')
bootstrap(C, cpu=True)
from dataset import NativeDataset, EpochBatches, action_window, collate, scan


class NativeTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.manifest = scan(C)
        cls.ds = NativeDataset(cls.manifest, C['action_horizon'])

    @classmethod
    def tearDownClass(cls):
        cls.ds.close()

    def test_complete_epochs_and_mid_epoch_resume(self):
        for n in [1, 41, 48, 49, 3209]:
            steps = int(np.ceil(n / 48))
            batches = list(EpochBatches(n, 48, 42, 0, steps * 3))
            for e in range(3):
                self.assertEqual(sorted(sum(batches[e*steps:(e+1)*steps], [])), list(range(n)))
            resumed = list(EpochBatches(n, 48, 42, min(2, steps), steps*3))
            self.assertEqual(resumed, batches[min(2, steps):])

    def test_actions_do_not_cross_episode_boundary(self):
        for e, end in enumerate(self.ds.ends):
            state, actions = self.ds.signals[e]
            start = end - len(state)
            self.assertEqual(self.ds.locate(start), (e, 0))
            self.assertEqual(self.ds.locate(end - 1), (e, len(state) - 1))
            np.testing.assert_array_equal(action_window(actions, len(state)-1, 16), np.repeat(actions[-1:], 16, axis=0))
            np.testing.assert_array_equal(action_window(actions, 12, 16), actions[12:28])

    def test_random_video_seek_matches_sequential_decode(self):
        import av
        from openpi_client.image_tools import resize_with_pad
        for ep in self.manifest['episodes']:
            targets = {0, 1, 29, ep['frames']//2, ep['frames']-1}
            for camera, file in ep['videos'].items():
                path = self.ds.root / file
                reference = {}
                with av.open(str(path)) as container:
                    for index, frame in enumerate(container.decode(video=0)):
                        if index in targets:
                            reference[index] = resize_with_pad(frame.to_ndarray(format='rgb24'), 224, 224).transpose(2,0,1)
                for index in sorted(targets, reverse=True):
                    np.testing.assert_array_equal(self.ds.image(path, index), reference[index])

    def test_masked_accumulation_matches_unpadded_gradient(self):
        import jax
        import jax.numpy as jnp
        from train import weighted_loss
        for count, multiple in [(41, 2), (1, 4), (48, 2)]:
            real = jnp.arange(count, dtype=jnp.float32) / 10
            batch = collate([{'x': np.asarray(x)} for x in real], multiple)
            xs, masks = jnp.asarray(batch['x']), jnp.asarray(batch['sample_mask'])
            expected = lambda w: jnp.mean((w * real - 1)**2)
            def accumulated(w):
                losses = []
                for x, mask in zip(jnp.split(xs, multiple), jnp.split(masks, multiple)):
                    losses.append(weighted_loss((w*x-1)**2, mask, masks.sum()))
                return sum(losses)
            np.testing.assert_allclose(accumulated(0.3), expected(0.3), rtol=1e-6)
            np.testing.assert_allclose(jax.grad(accumulated)(0.3), jax.grad(expected)(0.3), rtol=1e-6, atol=1e-6)

    def test_no_flag_filter_or_validation_split(self):
        self.assertEqual(len(self.ds), sum(x['frames'] for x in self.manifest['episodes']))
        self.assertEqual(self.manifest['summary']['validation_frames'], 0)
        self.assertEqual(len(self.ds.signals), self.manifest['summary']['episodes'])

    def test_action_transform_roundtrip(self):
        from train import build_config, data_config_and_transform
        from openpi import transforms
        cfg = build_config(C, self.manifest, 'test')
        dc, _ = data_config_and_transform(cfg, self.manifest)
        inp = transforms.compose([*dc.data_transforms.inputs, transforms.Normalize(dc.norm_stats, use_quantiles=dc.use_quantile_norm)])
        out = transforms.compose([transforms.Unnormalize(dc.norm_stats, use_quantiles=dc.use_quantile_norm), *dc.data_transforms.outputs])
        sample = self.ds[20]
        target = sample['actions'].copy()
        restored = out(inp(sample))['actions']
        np.testing.assert_allclose(restored, target, atol=1e-6)


if __name__ == '__main__':
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(NativeTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    write_json(ROOT / 'reports/unit_tests.json', {'tests': result.testsRun, 'failures': len(result.failures), 'errors': len(result.errors), 'passed': result.wasSuccessful()})
    raise SystemExit(0 if result.wasSuccessful() else 1)
