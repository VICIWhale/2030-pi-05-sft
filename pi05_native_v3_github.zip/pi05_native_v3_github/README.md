# PiperX π0.5 原生 v3 数据微调

从实际运行的双卡训练工程导出的代码包。支持当前 PiperX/Quest 采集器每目录一个 episode 的 MP4/Parquet 数据；不是任意 LeRobot v3 分片格式的通用加载器。

## 当前配置

122 条轨迹、176,283 帧；每轮随机打乱帧级样本，seed 42；完整保留轨迹和标记帧，不设验证集。当前观测预测连续 16 帧动作，轨迹末尾补齐，不跨轨迹。三路 RGB，14 维动作（左 6 关节、左夹爪、右 6 关节、右夹爪），关节 rad、夹爪 m。

双 GPU，总 batch 48，每卡 24，累积 1；语言 LoRA rank/alpha 32/32，动作 64/64。视觉分支等也按原 OpenPI 冻结规则参与训练，并非只有 LoRA 参数。学习率峰值 2.5e-5，预热 0.1 轮，余弦降至 2.5e-6；20 轮共 73,460 步。每轮独立保存 checkpoint，保留每轮模型。

## 文件

- train.py、dataset.py、runtime.py：训练、原生读取器和进程配置。
- progress.py：自动生成训练进度 Markdown/JSON。
- config.json / config.example.json：本次训练参数，使用可修改的相对数据和权重路径。
- runtime/openpi、runtime/vendor/lerobot：实际使用的依赖源码及许可证。
- requirements.lock.txt：当前服务器的精确 Python 包版本。
- tools/check_parallel.py：完整视频与边界随机读取检查。
- tools/doctor.py：仅检查环境导入，默认 CPU。

数据集另存于 https://modelscope.cn/datasets/SheaWang/2030-pi05-sft （私有仓库需授权，上传完成后下载）。GitHub 只放本代码包；数据、checkpoint、基础权重、缓存、访问 Token 不包含在内。

## 新服务器准备

目标环境：Linux x86_64、Python 3.11、NVIDIA GPU 和兼容 CUDA 12 的驱动。本次双卡训练实测每卡约 33 GiB 占用；24 GiB 显卡不能直接照搬此 batch。可减小 batch 或单卡使用梯度累积；双卡当前只支持累积 1。

```bash
# 可选清华 PyPI 镜像，仅影响这次安装
PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple bash setup.sh
source runtime/environment.sh
"$PIPERX_NATIVE_PYTHON" tools/doctor.py
```

setup.sh 在本目录建立独立 .venv，按版本清单安装，并安装随包提供的三个本地源码包。没有打包驱动或原服务器的 LD_LIBRARY_PATH 补丁；目标机器驱动需要自行匹配。全新机器从零安装尚未实测，参考 VALIDATION.json 的验证范围。

若已有兼容环境，可只生成入口配置，不安装/修改该环境：

```bash
PIPERX_NATIVE_PYTHON=/absolute/path/to/python bash setup.sh --reuse
```

数据放在 `data/piper_x_quest3s_dataset_20260919/data`，或修改 config.json 的 source_root。基础权重目录放在 `weights/pi05_base/params`，或修改 base_params。基础权重来源见 https://github.com/Physical-Intelligence/openpi#model-checkpoints （pi05_base）。还需 OpenPI 的 tokenizer 缓存；可从已有机器复制其 OpenPI/HuggingFace 缓存到本工程 cache，或允许首次联网下载。缓存无凭证文件时再复制，不要将缓存提交 GitHub。

## 检查与训练

```bash
bash run.sh scan --config config.json
source runtime/environment.sh
"$PIPERX_NATIVE_PYTHON" tools/check_parallel.py --config config.json --workers 8
bash run.sh stats --config config.json
"$PIPERX_NATIVE_PYTHON" tools/check_training_batches.py --config config.json
mkdir -p logs
nohup bash run.sh train --config config.json --experiment full122_v3 > logs/full122_v3.log 2>&1 < /dev/null &
```

数据改变后重新执行 check/stats。config.example.json 保存原始参考配置；机器相关配置建议另存 config.local.json 并显式传入 --config。

进度：`reports/训练进度.md`，同时在工程父目录创建 `π0.5训练进度.md`；每 30 秒和每 10 步刷新。实验目录还保存 progress.md、metrics.jsonl、run.json。全部模型位于 `checkpoints/pi05_piperx_native_v3_lora/<实验名>/<步数>/`。

同工程、同配置恢复：

```bash
bash run.sh train --config config.json --experiment full122_v3 --resume
```

本包用于迁移代码和重新训练。当前训练的 checkpoint 未包含；跨机器恢复已有训练还有绝对路径、源文件指纹、归一化及优化器状态校验，需要单独迁移并核对，不能仅复制 checkpoint 后假定 --resume 可用。不要删除严格校验来绕过不匹配。

## GitHub

在此文件夹初始化 Git 仓库即可。已有 .gitignore 排除数据和训练产物。公开或私有由仓库拥有者选择；新增项目代码许可证尚未选定。第三方源码许可证和修改说明见 THIRD_PARTY.md。
