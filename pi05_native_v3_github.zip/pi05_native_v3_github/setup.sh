#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ "${1:-}" == "--reuse" ]]; then
  : "${PIPERX_NATIVE_PYTHON:?Set PIPERX_NATIVE_PYTHON to an existing compatible Python executable}"
else
  "${PYTHON_BIN:-python3.11}" -m venv .venv
  .venv/bin/python -c 'import sys; assert sys.version_info[:2] == (3,11), "Use Python 3.11"'
  .venv/bin/python -m pip install --no-deps -r requirements.lock.txt
  .venv/bin/python -m pip install --no-deps ./runtime/vendor/lerobot ./runtime/openpi/packages/openpi-client ./runtime/openpi
  export PIPERX_NATIVE_PYTHON="$PWD/.venv/bin/python"
fi
"$PIPERX_NATIVE_PYTHON" tools/configure_environment.py
printf 'Environment prepared. Edit config.json, then run scan/check/stats before train.\n'
