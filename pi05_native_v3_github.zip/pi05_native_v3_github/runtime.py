"""Use an isolated source snapshot and the server's proven Python environment."""
import dataclasses
import hashlib
import json
import os
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent


def read_json(path):
    return json.loads(Path(path).read_text())


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2, allow_nan=False) + "\n")
    tmp.replace(path)


def digest(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(4 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def load_settings(path):
    path = Path(path).resolve()
    c = read_json(path)
    for key in ("source_root", "base_params"):
        c[key] = str((path.parent / Path(c[key]).expanduser()).resolve())
    for key in ("epochs", "batch_size", "gradient_accumulation_steps", "action_horizon", "fps", "language_rank", "action_rank", "log_interval"):
        if type(c[key]) is not int or c[key] <= 0:
            raise ValueError(f"{key} must be a positive integer")
    if type(c["num_workers"]) is not int or c["num_workers"] < 0:
        raise ValueError("num_workers must be a non-negative integer")
    import math
    if not math.isfinite(c["learning_rate"]) or c["learning_rate"] <= 0:
        raise ValueError("learning_rate must be finite and positive")
    if not math.isfinite(c["warmup_epochs"]) or c["warmup_epochs"] < 0:
        raise ValueError("warmup_epochs must be finite and non-negative")
    ids = c["gpu_ids"].split(",")
    if not all(x.isdigit() for x in ids) or len(set(ids)) != len(ids):
        raise ValueError("gpu_ids must contain distinct GPU indices")
    if c["batch_size"] % (len(ids) * c["gradient_accumulation_steps"]):
        raise ValueError("batch_size must divide across GPUs and accumulation steps")
    if len(ids) > 1 and c["gradient_accumulation_steps"] != 1:
        raise ValueError("Use accumulation=1 for multi-GPU; single-GPU supports accumulation")
    return c


def bootstrap(c, cpu=False):
    os.environ["CUDA_VISIBLE_DEVICES"] = "" if cpu else c["gpu_ids"]
    os.environ["JAX_PLATFORMS"] = "cpu" if cpu else "cuda"
    os.environ["XLA_PYTHON_CLIENT_PREALLOCATE"] = "false"
    os.environ.setdefault("OMP_NUM_THREADS", "1")
    os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
    os.environ["TOKENIZERS_PARALLELISM"] = "false"
    os.environ["WANDB_MODE"] = "disabled"
    snapshot = ROOT / "runtime/openpi"
    if not (snapshot / "src/openpi/models/pi0.py").exists():
        raise RuntimeError("Run bash setup.sh first")
    sys.path[:0] = [str(snapshot / "src"), str(snapshot / "packages/openpi-client/src"), str(snapshot)]
    # Only changes this process; the original OpenPI files and running policy are untouched.
    from openpi.models import gemma, lora
    original = getattr(gemma.get_config, "_native_original", gemma.get_config)
    def get_config(variant):
        result = original(variant)
        rank = {"gemma_2b_lora": c["language_rank"], "gemma_300m_lora": c["action_rank"]}.get(variant)
        if rank is not None:
            result = dataclasses.replace(result, lora_configs={k: lora.LoRAConfig(rank=rank, alpha=float(rank)) for k in result.lora_configs})
        return result
    get_config._native_original = original
    gemma.get_config = get_config


def code_fingerprint():
    files = {p.name: digest(p) for p in ROOT.glob("*.py")}
    files["snapshot"] = digest(ROOT / "runtime/source_manifest.json")
    return files
