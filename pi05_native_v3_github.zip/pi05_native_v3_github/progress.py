"""Small, atomic Markdown progress report; does not import the training stack."""
from collections import deque
import datetime
import json
import logging
import os
from pathlib import Path
import threading
import time


def duration(seconds):
    if seconds is None:
        return "估算中（至少等待 20 个稳定更新）"
    seconds = max(0, int(seconds))
    return f"{seconds // 3600} 小时 {seconds % 3600 // 60} 分 {seconds % 60} 秒"


class Progress:
    def __init__(self, paths, experiment, steps_per_epoch, epochs, checkpoint_dir, settings):
        self.paths = [Path(p) for p in paths]
        self.started = self.previous = time.monotonic()
        self.losses = deque(maxlen=100)
        self.durations = deque(maxlen=100)
        self.updates = 0
        self.lock = threading.RLock()
        self.done = threading.Event()
        self.thread = None
        self.data = dict(status="准备完成，尚未开始", experiment=experiment, pid=None,
                         step=0, steps_per_epoch=steps_per_epoch, epochs=epochs,
                         total_steps=steps_per_epoch * epochs, checkpoint_dir=str(checkpoint_dir),
                         latest_checkpoint=None, latest_checkpoint_step=0, settings=settings,
                         loss=None, loss_mean_100=None, learning_rate=None, last_step_time=None,
                         error=None, resume_step=0)

    def flush(self):
        with self.lock:
            d = dict(self.data)
            d["updated_at"] = datetime.datetime.now().astimezone().isoformat(timespec="seconds")
            d["elapsed_seconds"] = time.monotonic() - self.started if d["pid"] else 0
            d["eta_seconds"] = ((d["total_steps"] - d["step"]) * sum(self.durations) / len(self.durations)
                                if len(self.durations) >= 20 else None)
            number = lambda v: "—" if v is None else f"{v:.6g}"
            md = f"""# π0.5 训练进度

状态：**{d['status']}**  
文档更新时间：{d['updated_at']}  
最近完成更新：{d['last_step_time'] or '尚未完成训练更新'}

| 项目 | 当前值 |
| --- | --- |
| 实验 | {d['experiment']} |
| 完成步数 | {d['step']:,} / {d['total_steps']:,}（{100 * d['step'] / d['total_steps']:.2f}%） |
| 完成轮数 | {d['step'] / d['steps_per_epoch']:.3f} / {d['epochs']} |
| 当前 loss | {number(d['loss'])} |
| 最近最多 100 步平均 loss | {number(d['loss_mean_100'])} |
| 当前学习率 | {number(d['learning_rate'])} |
| 本次进程运行时间 | {duration(d['elapsed_seconds'])} |
| 预计剩余时间 | {duration(d['eta_seconds'])} |
| 已落盘 checkpoint 步数 | {d['latest_checkpoint_step']} |
| GPU | {d['settings']['gpu_ids']} |
| 总 batch | {d['settings']['batch_size']} |
| LoRA rank（语言 / 动作） | {d['settings']['language_rank']} / {d['settings']['action_rank']} |
| 训练进程 PID | {d['pid'] or '尚未启动'} |

最新完整 checkpoint：`{d['latest_checkpoint'] or '尚无'}`

实验目录：`{d['checkpoint_dir']}`  
完整逐步指标：该目录下 `metrics.jsonl`。每轮完成后保存独立 checkpoint，保留全部轮次。

文档每 30 秒及每 10 步更新，保存模型和退出时立即更新。时间估计包含数据读取和模型更新，初始编译阶段暂不估计；检查点写入可能引起波动。
若文档时间超过 2 分钟未更新，应检查训练进程；强制杀进程或断电无法写入退出状态。VS Code Remote SSH 中打开此文件可查看服务器最新内容。
训练 loss 表示示范拟合程度，不代表真实机械臂任务成功率。
"""
            if d["error"]:
                md += f"\n异常信息：\n\n```text\n{d['error']}\n```\n"
            for path in self.paths:
                for target, content in [(path, md), (path.with_suffix('.json'), json.dumps(d, ensure_ascii=False, indent=2) + '\n')]:
                    try:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        tmp = target.with_name(target.name + f'.{os.getpid()}.tmp')
                        tmp.write_text(content)
                        tmp.replace(target)
                    except OSError:
                        logging.exception("Could not update progress file %s", target)

    def phase(self, status, **fields):
        with self.lock:
            self.data.update(status=status, **fields)
            self.flush()

    def start(self):
        self.phase("初始化模型／准备数据", pid=os.getpid())
        def heartbeat():
            while not self.done.wait(30):
                self.flush()
        self.thread = threading.Thread(target=heartbeat, daemon=True)
        self.thread.start()

    def resume(self, step):
        with self.lock:
            self.data.update(step=step, resume_step=step)
            if step:
                self.data.update(latest_checkpoint_step=step, latest_checkpoint=str(Path(self.data['checkpoint_dir']) / str(step)))
            self.previous = time.monotonic()
            self.phase("等待首个 batch／编译训练步骤")

    def update(self, row):
        with self.lock:
            now = time.monotonic()
            self.updates += 1
            if self.updates > 3:
                self.durations.append(now - self.previous)
            self.previous = now
            self.losses.append(row['loss'])
            self.data.update(status="训练中", step=row['step'], loss=row['loss'],
                             loss_mean_100=sum(self.losses) / len(self.losses),
                             learning_rate=row['learning_rate'], last_step_time=row['time'])
            if self.updates == 1 or row['step'] % 10 == 0:
                self.flush()

    def finish(self, status, error=None):
        self.done.set()
        if self.thread:
            self.thread.join(timeout=5)
        self.phase(status, error=error)
